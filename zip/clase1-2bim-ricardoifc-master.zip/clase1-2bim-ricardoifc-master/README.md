# clase1-2bim
