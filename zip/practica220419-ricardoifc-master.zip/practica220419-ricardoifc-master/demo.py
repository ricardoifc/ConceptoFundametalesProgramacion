"""
	Ejemplo de lenguaje Python
	autor:@ricardoifc
"""

import sys

variable = sys.argv [0]
dato1 = sys.argv [1]
dato2 = sys.argv [2]
dato3 = sys.argv [3]

print ("variable argv[0]:	%s" % variable)
print ("variable argv[1]:	%s" % dato1)
print ("variable argv[2]:	%s" % dato2)
print ("variable argv[3]:	%s" % dato3)
