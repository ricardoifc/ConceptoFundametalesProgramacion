package manejolecturaarchivos;

// Este programa prueba la clase LeerArchivoTexto.

public class PruebaLeerArchivoTexto
{
   public static void main( String args[] )
   {
      // LeerArchivoTexto.leerRegistros();
      LeerArchivoTextoDos.leerRegistros();

   } // fin de main
} // fin de la clase PruebaLeerArchivoTexto

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 
 *************************************************************************/