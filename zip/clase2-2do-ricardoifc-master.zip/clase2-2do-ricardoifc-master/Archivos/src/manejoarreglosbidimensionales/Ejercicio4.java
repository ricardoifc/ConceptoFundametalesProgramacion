/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manejoarreglosbidimensionales;

/**
 *
 * @author reroes
 */
public class Ejercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int[][] arreglo = new int[2][];
        
        arreglo[0] = new int[3];
        arreglo[1] = new int[3];
        
        // Imprimir la primera fila del arreglo bidimensional
        System.out.println(arreglo[0][0]);
        System.out.println(arreglo[0][1]);
        System.out.println(arreglo[0][2]);
        
        System.out.println("---------------------");
        
        // Imprimir la segunda fila del arreglo bidimensional
        System.out.println(arreglo[1][0]);
        System.out.println(arreglo[1][1]);
        System.out.println(arreglo[1][2]);
        
        
        
        
        
    }
    
}
