/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manejoarreglosbidimensionales;

/**
 *
 * @author reroes
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
   /* public static void main(String[] args) {
        // TODO code application logic here

        int[][] arreglo = {10, 20}, {30, 40};
        String cadena = "";
        String cadenaDos = "";
        int suma ;
        int contador = 0;

        // Imprimir la primera fila del arreglo bidimensional
        // System.out.println(arreglo[0][0]); // fila 1 columna 1
        // System.out.println(arreglo[0][1]); // fila 1 columna 2
        // Imprimir la segunda fila del arreglo bidimensional
        // System.out.println(arreglo[1][0]); // fila 2 columna 1
        //System.out.println(arreglo[1][1]); // fila 2 columna 2
        for (int fila = 0; fila < arreglo.length; fila++) {
            cadenaDos = String.format("%s%s", cadenaDos,"los valores son:");
            suma = 0;
            for (int columna = 0; columna < arreglo.length; columna++) {
                cadena = String.format("%s%d\t", cadena, arreglo[fila][columna]);
                suma = arreglo[fila][columna] + suma;
            }
            cadenaDos = String.format("%s%d\n",cadenaDos,suma);
            cadena = String.format("%s\n\n", cadena);
        }
        System.out.printf("%s%s\n", cadena,cadenaDos);

    }
*/
}
