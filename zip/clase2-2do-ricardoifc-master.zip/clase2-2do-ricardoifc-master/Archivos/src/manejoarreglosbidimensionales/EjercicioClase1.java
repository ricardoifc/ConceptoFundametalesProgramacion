/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manejoarreglosbidimensionales;

/**
 *
 * @author Ricardo Freire
 */
public class EjercicioClase1 {
    public static void main(String[] args) {
        int [] valores = new int [3];
        int [][] matriz = new int [2][3];
        System.out.println(matriz[0][2]);
        matriz[1][1]=20;
        System.out.println(matriz[1][1]);
        
    }
}
