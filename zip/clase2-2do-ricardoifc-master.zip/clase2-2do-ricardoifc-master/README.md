# clase2-2bim

## Ejercicios de tipo académico
