/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete1;

/**
 *
 * @author Ricardo Freire
 */
public class Operacion {
        public static String mensaje = "Usted esta aprobado con";
    public static String mensaje2 = "Usted esta reprobado con";
}
