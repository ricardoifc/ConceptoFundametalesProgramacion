/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicoenclase;

import paquete1.*;
import java.util.Scanner;
/**
 *
 * @author Ricardo Freire
 */
public class SeleccionDoble {
    public static void main(String[] args) {
     // documentacion
     String miMensaje = Operacion.mensaje;}
     String miMensaje2 = Operacion.mensaje2;}
    Scanner entrada=new Scanner(System.in);
     int calificacion;
    System.out.println("Ingrese la segunda calificacion");
    calificacion = entrada.nextInt();
     
     if (calificacion >= 90){
        System.out.printf("%s %d/n",miMensaje, calificacion);
    } else {
        if (calificacion < 80 && calificacion 50){
      System.out.printf("Usted esta aprobado (regular) con %d/n",miMensaje, calificacion);
}
}
int calificacion_2;
    System.out.println("Ingrese la segunda calificacion");
    calificacion_2 = entrada.nextInt();
if (calificacion_2 >= 85) {
    System.out.printf("%s %d\n",miMensaje2, calificacion_2);
}
}
