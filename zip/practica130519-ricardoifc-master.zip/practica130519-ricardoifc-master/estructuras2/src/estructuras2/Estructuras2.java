/*
Estructuras2
 */
package estructuras2;

/**
 @author Ricardo Freire
 */
public class Estructuras2 {
    public static void main(String[] args) {
        // el encabezado de la instrucción for incluye la inicilializacion,
        // la condición de continuacion de ciclo y el incremento
        for (int contador=1;contador <= 10; contador++) {
            System.out.printf("%d ", contador);
        }
        System.out.println();
    } // fin de clase Contador For
    
}
