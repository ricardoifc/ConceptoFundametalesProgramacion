"""
	Este es mi presentacion en python
	:3
"""
nombre="Ricardo"
apellido="Freire"
print(nombre)
print(apellido)
