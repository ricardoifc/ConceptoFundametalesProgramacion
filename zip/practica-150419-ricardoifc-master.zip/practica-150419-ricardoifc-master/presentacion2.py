"""
	Este es el tercer ejemplo 
	en lenguaje python

	Ingreso de ingormacion por teclado

	@ricardoifc
"""
nombre= input("Porfavor ingrese su nombre:\n")
apellido= input("Porfavor ingrese su apellido:\n")
print("mi nombre es: %s\n\tMi apellido es:\n%s" % (nombre, apellido))