"""
@ricardoifc
"""
print("----Atención Canina----\n")
print("Datos del propietario\n")
cedula = input("Su Cedula:\n")
print("Datos del canino\n")
nombre = input("Nombre del perro:\n")
raza = input("Raza del perro:\n")
edad = input("Edad del perro\n")
peso = input("Peso del perro:\n")
peso = float(peso)
float(tarifa)

if (peso <= 5):
    tarifa=55
else:
    if (peso >= 7 & peso <=16):
        tarifa=175
    else:
        if (peso >= 14.1 & peso <=40):
            tarifa=205
        else:
            if (peso >= 7 & peso <=16):
                tarifa=325
print("Datos del propietaro\n\tCedula: %s\nDatos del perro"
	+":\n\tNombre: %s\n\tRaza: %s\n\tEdad: %s\n\tPeso: "
	+"%.1f\n\tTarifa semanal: "
        + "%.2$"% (cedula+nombre+raza+edad+eso+tarifa));
