/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete2;

/**
 *
 * @author reroes
 */
public class Clase221 {
    
    public static void main(String[] args) {
        
        // uso de expresionLogica ? expresion_1 : expresion_2
        
        int edad = 20;
        
        // ? es pregunta: es si no)
        String resultado = edad >=18 ? "Es mayor de edad" : "Es menor de edad";
        
        System.out.printf("resultado es: %s\n", resultado);
        
    }
}
