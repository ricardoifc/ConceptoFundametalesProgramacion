# 2do-grupal2

### En función del archivo registro2.json
- Obtener el promedio de calificaciones.
- Presentar el promedio de calificaciones en un archivo llamado promedio.txt; con el texto:
El promedio de calificaciones es ?
