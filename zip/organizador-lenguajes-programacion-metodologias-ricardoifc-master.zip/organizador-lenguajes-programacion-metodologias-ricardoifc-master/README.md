# lenguajes-programacion-metodologias

## Realizar dos organizadores gráficos sobre:
- Evolución de los lenguajes de programación.
- Metodologías de desarrollo.

## Subir cada organizador en formato de imagen (jgp, png)
