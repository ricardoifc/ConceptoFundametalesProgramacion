# practica200519

# Lenguaje Python


## Manejo de ciclo while

## Manejo de ciclo for
