package manejoescrituraarchivos;

public class PruebaCrearArchivoTexto {

    public static void main(String args[]) {
        CrearArchivoTexto.agregarRegistros("Información en el archivo");

    } // fin de main
} // fin de la clase PruebaCrearArchivoTexto

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *************************************************************************/
