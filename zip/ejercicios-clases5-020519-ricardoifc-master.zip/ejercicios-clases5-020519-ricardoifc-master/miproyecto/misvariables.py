"""
	file: misvariables.py
	autor: @ricardoifc
"""

# creación de variables importantes

mensaje = "Aprobado"
mensaje2 = "Reprobado"
mensaje3 = "Sobresaliente"
mensaje4 = "Muy buena"
mensaje5 = "Sobresaliente"