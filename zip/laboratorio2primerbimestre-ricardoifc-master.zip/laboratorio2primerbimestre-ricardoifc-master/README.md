# laboratorio2PrimerBimestre




##### Ejercicio planteado con fines educativos
