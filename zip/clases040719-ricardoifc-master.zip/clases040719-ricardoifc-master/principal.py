"""
"""

from librerias.mis_metodos import *

print(variable)
