"""
Principal test
"""
def obtener_suma(x, y):
	suma = x + y
	return suma

def promedio_notas(a, b, c):
	promedio = (a + b + c)/3
	return promedio