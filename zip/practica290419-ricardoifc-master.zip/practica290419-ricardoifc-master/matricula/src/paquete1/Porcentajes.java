/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete1;
import principal.ClasePrincipal;

/**
 *
 * @author Ricardo Freire
 */
public class Porcentajes {
public static float ciudad = (float) (ClasePrincipal.matricula *0.20);
public static float edad = (float) (ClasePrincipal.matricula *0.10);
public static float civil = (float) (ClasePrincipal.matricula *0.05);
public static float cargoFamiliares = (float) (ClasePrincipal.matricula *0.03);
       
}
