# ejercicios-clase6-090519
## Ejercicios con fines académicos
